### Hexlet tests and linter status:
[![Actions Status](https://github.com/lyovaparsyan94/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/lyovaparsyan94/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/84bf161038a06bd52b1f/maintainability)](https://codeclimate.com/github/lyovaparsyan94/python-project-49/maintainability)

### make lint, make brain-games, make brain-even: https://asciinema.org/a/HlwDeRJ4J3niG6VXs7Eiii7RN
### make brain-gcd: https://asciinema.org/a/o2ihRrHA8O3Ir3zRA5bwbgZW3
### make brain-progressions https://asciinema.org/a/ECwXKFGMlzmyqR5C37yL5lfvW
### make brain-prime https://asciinema.org/a/qO8MnWwg6Tvd9veU0fu6UKYA0