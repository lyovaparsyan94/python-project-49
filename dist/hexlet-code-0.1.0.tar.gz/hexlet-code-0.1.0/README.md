### Hexlet tests and linter status:
[![Actions Status](https://github.com/lyovaparsyan94/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/lyovaparsyan94/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/84bf161038a06bd52b1f/maintainability)](https://codeclimate.com/github/lyovaparsyan94/python-project-49/maintainability)